# neuralspace/tokenizer.py
import math
import hashlib
import re
import yaml
from pathlib import Path

# Load custom rules from YAML file
_RULES_CACHE = None
RULES_PATH = Path(__file__).parent.parent / "custom_rules.yaml"

def _load_rules():
    global _RULES_CACHE
    if _RULES_CACHE is not None:
        return _RULES_CACHE
    
    default_rules = [
        {"tokens": ["requests", "exec"], "boost": 5.0},
        {"tokens": ["base64", "exec"], "boost": 5.0},
        {"tokens": ["requests", "base64", "exec"], "boost": 8.0},
        {"tokens": ["os", "system"], "boost": 5.0},
        {"tokens": ["socket", "connect"], "boost": 5.0},
        {"tokens": ["subprocess", "Popen"], "boost": 5.0},
    ]
    
    if RULES_PATH.exists():
        try:
            with open(RULES_PATH, 'r') as f:
                data = yaml.safe_load(f)
                if data and 'rules' in data:
                    _RULES_CACHE = data['rules']
                    return _RULES_CACHE
        except Exception as e:
            print(f"Warning: Could not load custom_rules.yaml: {e}")
    
    _RULES_CACHE = default_rules
    return _RULES_CACHE

def code_to_512vec(code_string: str):
    counts = [0.0] * 512
    threat_indicators = {"os", "sys", "eval", "exec", "socket", "subprocess", "open", "rm", "rf", "input", "compile"}
    algo_indicators = {"def", "return", "sorted", "math", "len", "range", "int", "float", "list", "if", "else"}

    tokens = re.findall(r'\b\w+\b|[^\w\s]', code_string)
    token_set = set(tokens)

    for token in tokens:
        h_base = int(hashlib.md5(token.encode()).hexdigest(), 16) % 120
        if token in threat_indicators or '/' in token or '\\' in token or 'rm' in token:
            idx = 340 + h_base
        elif token in algo_indicators:
            idx = 20 + h_base
        else:
            idx = 160 + h_base
        counts[idx] += 1.0

    # --- DYNAMIC COMBINATION FEATURES (Loaded from custom_rules.yaml) ---
    rules = _load_rules()
    for i, rule in enumerate(rules):
        token_list = rule.get('tokens', [])
        boost = rule.get('boost', 5.0)
        if all(t in token_set for t in token_list):
            idx = 500 + (i % 10)
            counts[idx] += boost

    # --- Byte trigram hashing ---
    raw = code_string.encode('utf-8', errors='replace')
    padded = raw + b'\x00\x00\x00'
    for i in range(len(raw)):
        tri_hash = ((padded[i] * 31 + padded[i+1]) * 31 + padded[i+2])
        idx = (tri_hash % 150) + 160
        counts[idx] += 0.5

    vec = [math.log1p(c) for c in counts]
    norm = math.sqrt(sum(v * v for v in vec))
    return [v / norm for v in vec] if norm > 0 else vec

def get_combination_hits(code_string: str):
    tokens = re.findall(r'\b\w+\b|[^\w\s]', code_string)
    token_set = set(tokens)
    hits = []
    rules = _load_rules()
    
    for rule in rules:
        if all(t in token_set for t in rule['tokens']):
            hits.append(f"{' + '.join(rule['tokens'])} ({rule.get('name', 'custom rule')})")
    
    return hits

def code_to_512vec_with_language(code_string: str, file_path: str):
    from pathlib import Path
    ext = Path(file_path).suffix.lower()
    if ext in {'.py', '.js', '.ts', '.go', '.rs', '.cpp', '.c', '.h', '.jsx', '.tsx'}:
        try:
            from neuralspace.ast_tokenizer import code_to_512vec_ast
            return code_to_512vec_ast(code_string, ext)
        except (ImportError, ModuleNotFoundError):
            return code_to_512vec(code_string)
    else:
        return code_to_512vec(code_string)